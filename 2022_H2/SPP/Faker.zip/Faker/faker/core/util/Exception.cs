﻿namespace faker.core.util;

public class CircularDependencyException: Exception { }

public class CantGenerateByConstructorException: Exception { }
