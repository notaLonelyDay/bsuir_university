﻿namespace faker.core;

public interface Faker
{
    T Create<T>();
}