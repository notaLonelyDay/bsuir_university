public struct Struct {
    public string Name { get; set; }
}