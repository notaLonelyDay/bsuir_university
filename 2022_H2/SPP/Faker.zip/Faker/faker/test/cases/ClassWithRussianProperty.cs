using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class ClassWithRussianProperty : Class {
    public int Возраст { get; set; }
}